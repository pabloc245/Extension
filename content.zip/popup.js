const SIZE = 120;
const CENTER = SIZE / 2;
const RADIUS_BG = 46;
const RADIUS_FG = 45;     
const LINE_BG = 10;
const LINE_FG = 10;

const autoInput = document.getElementById("auto");
const highlightInput = document.getElementById("hl");
const networkInput = document.getElementById("net");
const colorInput = document.getElementById("hlColor");

let stats = {
  err: 10,
  ok: 0,
  levels: []
};

let params = {
  highlight: false,
  color: "yellow",
  network: true,
  auto: false,
};

const canvas = document.getElementById('gauge');
const ctx = canvas.getContext('2d');

const dpr = window.devicePixelRatio || 1;
canvas.width = SIZE * dpr;
canvas.height = SIZE * dpr;
canvas.style.width = `${SIZE}px`;
canvas.style.height = `${SIZE}px`;
ctx.scale(dpr, dpr);
ctx.lineCap = 'round';

function drawGauge() {
  try {
    const total = stats.err + stats.ok || 1;
    const ratio = stats.err / total;

    ctx.clearRect(0, 0, SIZE, SIZE);

    ctx.lineWidth = LINE_BG;
    ctx.beginPath();
    ctx.strokeStyle = '#7fff7f';
    ctx.arc(CENTER, CENTER, RADIUS_BG, 0, Math.PI * 2);
    ctx.stroke();

    ctx.lineWidth = LINE_FG;
    ctx.beginPath();
    ctx.strokeStyle = '#be1f27';
    ctx.arc(
      CENTER,
      CENTER,
      RADIUS_FG,
      -Math.PI / 2,
      Math.PI * 2 * ratio - Math.PI / 2
    );
    ctx.stroke();
  } catch (e) {
    console.error('[POPUP] drawGauge error:', e);
  }
}

function render() {
  try {
    document.getElementById('err').textContent = stats.err;
    document.getElementById('ok').textContent = stats.ok;

    list.innerHTML = '';
    stats.levels.slice(-12).forEach(l => {
      const li = document.createElement('li');
      li.textContent = `level_${l.id}.json`;
      li.className = l.err ? 'err' : 'ok';
      list.appendChild(li);
    });

    drawGauge();
  } catch (e) {
    console.error('[POPUP] render error:', e);
  }
}

function updateParam(partial) {
  if (!partial || typeof partial !== 'object') {
    console.error('[POPUP] Invalid param update');
    return Promise.reject(new Error('Invalid param'));
  }

  return browser.runtime.sendMessage({
    type: "UPDATE_PARAMS",
    payload: partial
  }).catch(err => {
    console.error('[POPUP] Update failed:', err);
    throw err;
  });
}

if (hlColor) {
  hlColor.oninput = () => {
    browser.storage.local.set({ highlightColor: hlColor.value })
      .catch(err => console.error('[POPUP] Storage failed:', err));
  };
}

if (reset) {
  reset.onclick = () => {
    console.log('[POPUP] reset');
    render();
  };
}

if (autoInput) {
  autoInput.addEventListener("change", () => {
    try {
      const value = autoInput.checked;
      params.auto = value;
      updateParam({ auto: value });
    } catch (e) {
      console.error('[POPUP] auto change error:', e);
    }
  });
}

if (highlightInput) {
  highlightInput.addEventListener("change", () => {
    try {
      const value = highlightInput.checked;
      params.highlight = value;
      updateParam({ highlight: value });
    } catch (e) {
      console.error('[POPUP] highlight change error:', e);
    }
  });
}

if (networkInput) {
  networkInput.addEventListener("change", () => {
    try {
      const value = networkInput.checked;
      params.network = value;
      updateParam({ network: value });
    } catch (e) {
      console.error('[POPUP] network change error:', e);
    }
  });
}

if (colorInput) {
  colorInput.addEventListener("input", () => {
    try {
      const value = String(colorInput.value);
      params.color = value;
      updateParam({ color: value });
    } catch (e) {
      console.error('[POPUP] color change error:', e);
    }
  });
}

browser.runtime.sendMessage({ type: "GET_PARAMS" })
  .then(p => {
    if (!p) {
      console.warn('[POPUP] No params received');
      return;
    }

    if (autoInput) autoInput.checked = !!p.auto;
    if (highlightInput) highlightInput.checked = !!p.highlight;
    if (networkInput) networkInput.checked = !!p.network;
    if (colorInput && p.color) colorInput.value = p.color;

    if (p.levels) {
      stats.levels = [...p.levels].map(level => ({ id: level }));
    }
    if (typeof p.errors === 'number') {
      stats.err = p.errors;
    }

    render();
  })
  .catch(err => {
    console.error('[POPUP] Failed to get params:', err);
    render();
  });

render();
